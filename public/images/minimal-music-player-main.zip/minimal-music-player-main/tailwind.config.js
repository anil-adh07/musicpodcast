/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      animation: {
        soundwave: "soundwave 1s infinite",
      },
      fontFamily: {
        sans: "Epilogue, sans-serif",
      },
      keyframes: {
        soundwave: {
          "0%, 100%": { transform: "scaleY(1)" },
          "50%": { transform: "scaleY(0.7)" },
        },
      },
    },
  },
  plugins: [],
};
