import { useState } from "react";
import { Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import Home from "./pages/Home";
import ArtistPage from "./pages/artist/[slug]";
import Player from "./components/Player";
import ScrollToTop from "./components/ScrollToTop";

type TrackPropType = {
  album_id: string;
  album_image: string;
  album_name: string;
  audio: string;
  audiodownload: string;
  audiodownload_allowed: boolean;
  duration: string;
  id: string;
  image: string;
  license_ccurl: string;
  name: string;
  releasedate: string;
};

const App = () => {
  const [trackIndex, setTrackIndex] = useState<number>(0);
  const [isPlayerOpen, setPlayerOpen] = useState<boolean>(false);
  const [trackList, setTrackList] = useState<TrackPropType[]>([]);

  const openPlayer = (tracks: TrackPropType[], index: number) => {
    setPlayerOpen(true);
    setTrackIndex(index);
    setTrackList(tracks);
  };

  return (
    <>
      <div className="bg-neutral-950 p-4 relative">
        <div className="w-full h-full min-h-screen flex flex-col gap-5">
          <div className="rounded-xl w-full h-full bg-neutral-900 p-6 mb-2">
            <ScrollToTop>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route
                  path="/artist/:slug/:name"
                  element={<ArtistPage openTrackPlayer={openPlayer} />}
                />
              </Routes>
            </ScrollToTop>
          </div>
          <div className="mb-24">
            <p className="text-center text-neutral-200 text-sm">
              Music &amp; Artists data from{" "}
              <a
                href="https://www.jamendo.com/"
                target="_blank"
                className="hover:underline text-[#FF1e58] underline-offset-4"
              >
                Jamendo
              </a>
            </p>
          </div>
        </div>
        {isPlayerOpen && (
          <Player trackIndex={trackIndex} trackList={trackList} />
        )}
      </div>
      <ToastContainer />
    </>
  );
};

export default App;
