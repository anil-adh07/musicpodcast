import { Link } from "react-router-dom";
import Markdown from "markdown-to-jsx";

type ArtistProps = {
  name: string;
  image: string;
  query: string;
};

const ArtistCard = ({ name, image, query }: ArtistProps) => {
  return (
    <Link
      to={`/artist/${query}/${name.split(" ").join("-")}`}
      className="group relative block bg-neutral-800 rounded-xl overflow-hidden max-h-80"
    >
      <img
        alt={name}
        src={
          image?.length
            ? image
            : `https://source.unsplash.com/600x600?${name}+music`
        }
        className="absolute inset-0 h-full w-full object-cover object-center opacity-75 transition-opacity group-hover:opacity-50"
      />
      {!image?.length && (
        <span className="absolute text-xs text-neutral-100 bottom-2 right-2">
          Image by Unsplash
        </span>
      )}

      <div className="relative p-4 sm:p-6 lg:p-8">
        <span className="text-sm font-medium uppercase tracking-widest text-green-300 drop-shadow">
          Artist
        </span>

        <div className="mt-48">
          <div className="translate-y-8 transform opacity-0 transition-all group-hover:translate-y-0 group-hover:opacity-100">
            <Markdown
              options={{ forceBlock: true }}
              className="text-xl font-bold text-neutral-100 sm:text-2xl capitalize line-clamp-2"
            >
              {name}
            </Markdown>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ArtistCard;
