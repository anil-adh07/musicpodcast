import useOnclickOutside from "react-cool-onclickoutside";
import Track from "./Track";

type TrackProps = {
  album_id: string;
  album_image: string;
  album_name: string;
  audio: string;
  audiodownload: string;
  audiodownload_allowed: boolean;
  duration: string;
  id: string;
  image: string;
  license_ccurl: string;
  name: string;
  releasedate: string;
};

type SheetProps = {
  closeSheet: () => void;
  currentTrackIndex: number;
  isOpen: boolean;
  tracks: TrackProps[] | null;
  updateTrackIndex: (index: number) => void;
};

const BottomSheet = ({
  tracks,
  isOpen,
  closeSheet,
  currentTrackIndex,
  updateTrackIndex,
}: SheetProps) => {
  const ref = useOnclickOutside(() => {
    closeSheet();
  });

  return (
    <div
      className={`
        fixed
        z-[90]
        inset-x-0
        md:px-6
        px-4
        rounded-t-2xl
        w-full
        h-auto
        md:max-h-[80vh]
        max-h-[90vh]
        ${isOpen ? "bottom-0" : "-bottom-full"}
        transition-all
        duration-500
        lg:max-w-screen-md
        mx-auto
        bg-neutral-900
      `}
      ref={ref}
    >
      <h3 className="sticky top-0 z-10 py-3 bg-neutral-900 text-neutral-100 md:text-2xl text-xl font-semibold">
        Upcoming Tracks
      </h3>
      <div className="h-[73vh]">
        <ul className="md:text-lg text-base h-full max-h-[73vh] pb-5 overflow-auto custom-scrollbar">
          {tracks?.length &&
            tracks.map((track, index: number) => (
              <li
                key={index}
                className="
                  group
                  cursor-pointer
                  w-full
                  flex
                  items-center
                  gap-4
                  text-neutral-100
                  p-2.5
                  rounded
                  hover:bg-neutral-800
                "
                title={track.name}
                onClick={() => updateTrackIndex(index)}
              >
                <Track track={track} isPlaying={index === currentTrackIndex} />
              </li>
            ))}
        </ul>
      </div>
    </div>
  );
};

export default BottomSheet;
