import { useState, useEffect, useRef } from "react";
import { toast } from "react-toastify";
import Markdown from "markdown-to-jsx";
import Marquee from "react-fast-marquee";
import "react-toastify/dist/ReactToastify.css";
import { convertDuration, extractDominantColor } from "../utils/data";
import Pause from "./icons/Pause";
import Play from "./icons/Play";
import PlayerNav from "./icons/PlayerNav";
import Audio from "./icons/Audio";
import ArrowUp from "./icons/ArrowUp";
import Loader from "./icons/Loader";
import Playlist from "./icons/Playlist";
import BottomSheet from "./BottomSheet";
import PlayerButton from "./PlayerButton";

type TrackProps = {
  album_id: string;
  album_image: string;
  album_name: string;
  audio: string;
  audiodownload: string;
  audiodownload_allowed: boolean;
  duration: string;
  id: string;
  image: string;
  license_ccurl: string;
  name: string;
  releasedate: string;
};

type PlayerProps = {
  trackIndex: number | 0;
  trackList: TrackProps[] | null;
};

const Player = ({ trackIndex, trackList }: PlayerProps) => {
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [isLoading, setLoading] = useState<boolean>(false);
  const [isPlaying, setPlaying] = useState<boolean>(false);
  const [isMinimized, setMinimized] = useState<boolean>(true);
  const [muted, setMuted] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.7);
  const [playPercentage, setPlayPercentage] = useState<number>(0);
  const [tooltipPlace, setTooltipPlace] = useState<number>(0);
  const [tooltipText, setTooltipText] = useState<string>("00:00");
  const [backgroundColor, setBackgroundColor] = useState<string>(
    "rgb(38 38 38 / 0.5)"
  );
  const [currentTrack, setCurrentTrack] = useState<TrackProps | null>(null);
  const [currentTrackIndex, setCurrentTrackIndex] =
    useState<number>(trackIndex);
  const [lastIndex, setLastIndex] = useState<number>(0);
  const [isBottomSheetOpen, setBottomSheetOpen] = useState<boolean>(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const tooltipRef = useRef<HTMLDivElement | null>(null);
  let updateTimer: string | number | NodeJS.Timeout | undefined;

  const pauseTrack = () => {
    setPlaying(false);
    audioRef?.current?.pause();
  };

  const playTrack = () => {
    setPlaying(true);
    audioRef?.current?.play();
  };

  const muteTrack = () => {
    if (audioRef?.current) {
      setMuted((value) => !value);
      audioRef.current.muted = !audioRef.current.muted;
    }
  };

  const updateSeekTime = () => {
    const audioElement = audioRef.current;
    if (audioElement) {
      const currentTime = audioElement.currentTime;
      const duration = audioElement.duration;
      setCurrentTime(currentTime);
      setDuration(duration);
      if (!isNaN(currentTime) && !isNaN(duration)) {
        setPlayPercentage((currentTime / duration) * 100);
      }
      audioElement.addEventListener("ended", () => {
        setPlaying(false);
        if (
          trackList &&
          trackList?.length > 0 &&
          currentTrackIndex !== lastIndex
        ) {
          playNext();
        }
      });
    }
  };

  const handleVolumeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(event.target.value);
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
  };

  const handleProgressBarClick = (event: React.MouseEvent<HTMLDivElement>) => {
    const audioElement = audioRef.current;
    if (audioElement) {
      const progressBar = event.currentTarget;
      const clickX = event.nativeEvent.offsetX;
      const width = progressBar.clientWidth;
      const seekTime = (clickX / width) * audioElement.duration;
      audioElement.currentTime = seekTime;
    }
  };

  const hideTooltip = (event: React.MouseEvent<HTMLDivElement>) => {
    event.preventDefault();
    tooltipRef?.current?.classList.add("hidden");
  };

  const displayTooltip = (event: React.MouseEvent<HTMLDivElement>) => {
    const audioElement = audioRef.current;

    if (audioElement) {
      const offset = event.nativeEvent.offsetX;
      const width = event.currentTarget.clientWidth;
      const hoveredTimeStamp = (offset / width) * duration;
      setTooltipText(convertDuration(hoveredTimeStamp.toString()));
      setTooltipPlace((offset / width) * 100);
      tooltipRef?.current?.classList.remove("hidden");
    }
  };

  const playPrevious = () => {
    if (trackList && trackList.length > 0) {
      if (currentTrackIndex === 0) {
        return;
      }
      setCurrentTrackIndex(currentTrackIndex - 1);
    }
  };

  const playNext = () => {
    if (trackList && trackList.length > 0) {
      if (currentTrackIndex === lastIndex) {
        return;
      }
      setCurrentTrackIndex(currentTrackIndex + 1);
    }
  };

  const getDominantColor = async (image: string) => {
    const dominantColor = await extractDominantColor(image);
    setBackgroundColor(`${dominantColor}80`);
  };

  useEffect(() => {
    const element = document.documentElement;
    isMinimized
      ? (element.style.overflowY = "auto")
      : (element.style.overflowY = "hidden");
  }, [isMinimized]);

  useEffect(() => {
    const audioElement = audioRef.current;
    clearInterval(updateTimer);
    setPlayPercentage(0);

    if (audioElement) {
      audioElement.pause();
      audioElement.currentTime = 0;

      if (trackList?.length) {
        const track = trackList?.find(
          (song) => trackList.indexOf(song) === currentTrackIndex
        );
        const lastTrackIndex: number = trackList.length - 1;
        setLastIndex(lastTrackIndex);

        if (track) {
          setCurrentTrack(track);
          getDominantColor(track?.image);
          audioElement.src = track.audio;
          audioElement.load();
          audioElement.volume = volume;

          audioElement.onloadstart = () => {
            setLoading(true);
          };
        }

        // Add an event listener for when the audio has loaded sufficiently
        audioElement.addEventListener("canplaythrough", () => {
          setLoading(false);
          audioElement.play().then(() => {
            setPlaying(true);
          });
          audioElement.addEventListener("timeupdate", updateSeekTime);
          // eslint-disable-next-line react-hooks/exhaustive-deps
          updateTimer = setInterval(updateSeekTime, 1000);
        });
      } else {
        audioElement.src = "";
        audioElement.pause();
        setPlaying(false);
        setPlayPercentage(0);
        toast.error("Track not available!", {
          position: "top-right",
          autoClose: 2500,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
    }
  }, [trackList, currentTrackIndex]);

  useEffect(() => {
    setCurrentTrackIndex(trackIndex);
  }, [trackIndex]);

  return (
    <>
      <div
        className={`fixed z-50 transition-all duration-300 ${
          isMinimized ? "bottom-0 inset-x-0" : "inset-0"
        } w-full p-4 backdrop-blur-xl flex items-center`}
        style={{ backgroundColor: backgroundColor }}
      >
        {isMinimized && (
          <div
            className="absolute top-0 mx-auto inset-x-0 w-full h-1 bg-neutral-700"
            role="button"
            onClick={handleProgressBarClick}
            onMouseOver={displayTooltip}
            onMouseMove={displayTooltip}
            onMouseOut={hideTooltip}
            onMouseLeave={hideTooltip}
          >
            <div
              className="relative h-full bg-green-400"
              style={{ width: `${playPercentage}%` }}
            />
            <div
              ref={tooltipRef}
              className="
              absolute
              hidden
              whitespace-nowrap
              px-5
              py-2
              text-xs
              bg-green-400
              text-neutral-100
              rounded
              bottom-4
              block
              transform
              transition
              transition-all
              duration-300
              -translate-x-1/2
              text-center
              z-10
            "
              style={{ left: `${tooltipPlace}%` }}
            >
              {tooltipText}
            </div>
          </div>
        )}
        {isMinimized ? (
          <div className="flex w-full items-center gap-3 mx-auto md:px-4">
            <div className="w-1/12 flex items-center justify-center">
              <PlayerButton
                classNames="md:inline-flex hidden"
                children={
                  <PlayerNav classNames="w-7 fill-neutral-100 -scale-x-100" />
                }
                disabled={currentTrackIndex === 0}
                isPrimary={false}
                onClick={playPrevious}
              />
              <PlayerButton
                children={
                  isLoading ? (
                    <Loader color="text-neutral-100" />
                  ) : isPlaying ? (
                    <Pause classNames="w-7 fill-neutral-100" />
                  ) : (
                    <Play classNames="w-7 fill-neutral-100 ml-1" />
                  )
                }
                disabled={isLoading}
                isPrimary={false}
                onClick={isPlaying ? pauseTrack : playTrack}
              />
              <PlayerButton
                classNames="md:inline-flex hidden"
                children={<PlayerNav classNames="w-7 fill-neutral-100" />}
                disabled={currentTrackIndex === lastIndex}
                isPrimary={false}
                onClick={playNext}
              />
            </div>
            <div className="w-10/12 grow flex items-center gap-3 overflow-hidden">
              <img
                src={currentTrack?.image}
                alt={currentTrack?.name}
                className="md:block hidden transition-all duration-300 w-16 h-16 object-cover object-center rounded-md"
              />
              <div className="flex flex-col w-full">
                <div className="relative w-full overflow-x-hidden">
                  <div className="whitespace-nowrap max-w-[150px]">
                    {currentTrack && (
                      <Marquee pauseOnHover={true} speed={20} className="gap-4">
                        <Markdown
                          options={{ wrapper: "h3", forceWrapper: true }}
                          className="text-neutral-100 font-semibold text-lg truncate"
                        >
                          {currentTrack.name}
                        </Markdown>
                      </Marquee>
                    )}
                  </div>
                  {currentTrack && currentTrack.album_name && (
                    <Markdown
                      className="text-xs text-neutral-200 truncate"
                      options={{ forceBlock: true }}
                    >
                      {currentTrack.album_name}
                    </Markdown>
                  )}
                </div>
              </div>
            </div>
            <div className="w-1/12 shrink-0 flex items-center justify-end gap-4">
              <PlayerButton
                classNames="md:inline-flex hidden w-10 h-10"
                children={
                  <Audio classNames="w-7 fill-neutral-200" muted={muted} />
                }
                disabled={false}
                isPrimary={false}
                onClick={muteTrack}
              />
              <PlayerButton
                children={<ArrowUp classNames="w-7 fill-neutral-100" />}
                disabled={false}
                isPrimary={false}
                onClick={() => setMinimized((value) => !value)}
              />
            </div>
          </div>
        ) : (
          <>
            <div className="flex flex-col gap-5 md:max-w-md w-full h-full justify-center items-center mx-auto">
              <img
                src={currentTrack?.image}
                alt={currentTrack?.name}
                className="transition-all duration-700 w-64 h-64 object-cover object-center rounded-xl"
              />
              <div className="relative text-center w-full overflow-x-hidden mx-auto">
                <div className="whitespace-nowrap mx-auto max-w-[60%]">
                  {currentTrack && (
                    <Marquee pauseOnHover={true} speed={20} className="gap-4">
                      <Markdown
                        options={{ wrapper: "h2", forceWrapper: true }}
                        className="text-neutral-100 font-semibold md:text-3xl text-2xl truncate"
                      >
                        {currentTrack.name}
                      </Markdown>
                    </Marquee>
                  )}
                </div>
                {currentTrack && currentTrack.album_name && (
                  <Markdown
                    className="text-sm text-neutral-200 truncate"
                    options={{ forceBlock: true }}
                  >
                    {currentTrack.album_name}
                  </Markdown>
                )}
              </div>
              <div className="grid grid-cols-5 gap-1 mx-auto w-full place-items-center">
                <span
                  className={`col-span-1 ${
                    isLoading ? "text-neutral-400" : "text-neutral-200"
                  } text-sm`}
                >
                  {isLoading
                    ? "00:00"
                    : convertDuration(currentTime.toString())}
                </span>
                <div
                  className="col-span-3 relative w-full h-1 bg-neutral-700"
                  role="button"
                  onClick={handleProgressBarClick}
                  onMouseOver={displayTooltip}
                  onMouseMove={displayTooltip}
                  onMouseOut={hideTooltip}
                  onMouseLeave={hideTooltip}
                >
                  <div
                    className="relative h-full bg-green-400"
                    style={{ width: `${playPercentage}%` }}
                  />
                  <div
                    ref={tooltipRef}
                    className="
                        absolute
                        hidden
                        whitespace-nowrap
                        px-5
                        py-2
                        text-xs
                        bg-green-400
                        text-neutral-100
                        rounded
                        bottom-4
                        block
                        transform
                        transition
                        transition-all
                        duration-300
                        -translate-x-1/2
                        text-center
                        z-10
                      "
                    style={{ left: `${tooltipPlace}%` }}
                  >
                    {tooltipText}
                  </div>
                </div>
                <span
                  className={`col-span-1 ${
                    isLoading ? "text-neutral-400" : "text-neutral-200"
                  } text-sm`}
                >
                  {isLoading ? "00:00" : convertDuration(duration.toString())}
                </span>
              </div>
              <div className="grid grid-cols-4 w-full md:px-3 gap-3 justify-items-stretch mx-auto">
                <div className="w-full col-span-3 flex items-center gap-3 justify-between sm:justify-self-start justify-self-center">
                  <div className="flex items-center gap-3 justify-evenly">
                    <PlayerButton
                      children={
                        <PlayerNav classNames="w-8 fill-neutral-100 -scale-x-100" />
                      }
                      disabled={currentTrackIndex === 0}
                      isPrimary={false}
                      onClick={playPrevious}
                    />
                    <PlayerButton
                      children={
                        isLoading ? (
                          <Loader color="text-neutral-800" />
                        ) : isPlaying ? (
                          <Pause classNames="w-7 fill-neutral-800" />
                        ) : (
                          <Play classNames="w-7 fill-neutral-800 ml-1" />
                        )
                      }
                      disabled={isLoading}
                      isPrimary={true}
                      onClick={isPlaying ? pauseTrack : playTrack}
                    />
                    <PlayerButton
                      children={<PlayerNav classNames="w-8 fill-neutral-100" />}
                      disabled={currentTrackIndex === lastIndex}
                      isPrimary={false}
                      onClick={playNext}
                    />
                  </div>
                  <div className="flex items-center gap-3">
                    <PlayerButton
                      classNames="w-8 h-8"
                      children={
                        <Audio
                          classNames="w-6 fill-neutral-200"
                          muted={muted}
                        />
                      }
                      disabled={false}
                      isPrimary={false}
                      onClick={muteTrack}
                    />
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.01"
                      value={volume}
                      onChange={handleVolumeChange}
                      className="relative rounded-lg accent-green-400 overflow-hidden appearance-none bg-neutral-700 h-1 w-full"
                    />
                  </div>
                </div>
                <div className="col-span-1 w-full flex items-center justify-end gap-3 sm:justify-self-end justify-self-center">
                  <PlayerButton
                    children={<Playlist classNames="w-6 fill-neutral-200" />}
                    disabled={false}
                    isPrimary={false}
                    onClick={() => setBottomSheetOpen(true)}
                  />
                </div>
              </div>
            </div>
            <PlayerButton
              classNames="absolute top-4 right-8 md:w-12 md:h-12 w-10 h-10"
              children={
                <ArrowUp classNames="w-7 fill-neutral-100 rotate-180" />
              }
              disabled={false}
              isPrimary={false}
              onClick={() => setMinimized((value) => !value)}
            />
          </>
        )}
        <audio ref={audioRef} />
      </div>
      <BottomSheet
        closeSheet={() => setBottomSheetOpen(false)}
        currentTrackIndex={currentTrackIndex}
        isOpen={isBottomSheetOpen}
        tracks={trackList}
        updateTrackIndex={(index) => setCurrentTrackIndex(index)}
      />
    </>
  );
};

export default Player;
