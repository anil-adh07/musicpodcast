import SearchIcon from "./icons/Search";

type SearchProps = {
  updateSearchTerm: (term: string) => void;
};

const Search = ({ updateSearchTerm }: SearchProps) => {
  const debounce = <F extends (...args: string[]) => void>(
    func: F,
    delay: number
  ) => {
    let timer: NodeJS.Timeout;

    return (...args: Parameters<F>) => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        func(...args);
      }, delay);
    };
  };

  const debouncedSearch = debounce((searchTerm: string) => {
    updateSearchTerm(searchTerm);
  }, 200);

  const captureInput = (event: React.ChangeEvent<HTMLInputElement>) => {
    debouncedSearch(event.target.value);
  };

  return (
    <div className="relative md:w-auto w-full md:max-w-xs mt-3">
      <span className="absolute inset-y-0 start-0 grid w-10 place-content-center">
        <SearchIcon classNames="w-6 h-6 text-neutral-200" />
      </span>
      <input
        type="text"
        id="Search"
        placeholder="Search artists"
        className="
          pl-10
          focus:outline-none
          ring-2
          ring-neutral-800
          focus:ring-neutral-600
          w-full
          rounded-md
          py-2.5
          pe-10
          shadow-sm
          sm:text-base
          bg-neutral-800
          text-neutral-100
          transition-all
          duration-300
        "
        onInput={captureInput}
        autoComplete="off"
      />
    </div>
  );
};

export default Search;
