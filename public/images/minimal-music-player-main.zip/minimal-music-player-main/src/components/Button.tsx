import Loader from "./icons/Loader";

type ButtonProps = {
  isLoading: boolean;
  title: string;
  type: "button" | "submit" | "reset";
  onClick: () => void;
};

const Button = ({ isLoading, title, type, onClick }: ButtonProps) => {
  return (
    <button
      disabled={isLoading}
      onClick={onClick}
      type={type}
      className="
        bg-neutral-100
        inline-flex
        items-center
        justify-center
        md:text-lg
        text-base
        text-neutral-900
        rounded-full
        py-2.5
        px-6
        mx-auto
        disabled:cursor-not-allowed
      "
    >
      {isLoading ? <Loader color="text-neutral-900" /> : title}
    </button>
  );
};

export default Button;
