import Markdown from "markdown-to-jsx";
import { convertDuration } from "../utils/data";
import Play from "./icons/Play";
import Synth from "./icons/Synth";

type TrackProps = {
  track: {
    album_id: string;
    album_image: string;
    album_name: string;
    audio: string;
    audiodownload: string;
    audiodownload_allowed: boolean;
    duration: string;
    id: string;
    image: string;
    license_ccurl: string;
    name: string;
    releasedate: string;
  };
  isPlaying?: boolean;
};

const Track = ({ track, isPlaying }: TrackProps) => {
  return (
    <>
      <div className="relative w-12 h-12 overflow-hidden rounded shrink-0">
        <img
          src={track.image}
          alt={track.name}
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 w-full h-full bg-neutral-900/50 transition-all duration-700">
          {isPlaying ? (
            <Synth classNames="w-6 fill-neutral-100 relative top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          ) : (
            <Play classNames="hidden group-hover:block w-6 fill-neutral-100 relative top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          )}
        </div>
      </div>
      <div className="flex flex-col grow truncate">
        <Markdown options={{ forceInline: true }}>{track.name}</Markdown>
        <Markdown options={{ forceInline: true }} className="text-xs">
          {track.album_name}
        </Markdown>
      </div>
      <span className="text-sm">{convertDuration(track.duration)}</span>
    </>
  );
};

export default Track;
