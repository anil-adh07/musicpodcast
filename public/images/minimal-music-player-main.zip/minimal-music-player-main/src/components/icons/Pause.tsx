type Props = {
  classNames?: string;
};

const Pause = ({ classNames }: Props) => {
  return (
    <svg viewBox="0 0 24 24" className={classNames}>
      <g>
        <path d="M9,19H7V5H9ZM17,5H15V19h2Z" />
      </g>
    </svg>
  );
};

export default Pause;
