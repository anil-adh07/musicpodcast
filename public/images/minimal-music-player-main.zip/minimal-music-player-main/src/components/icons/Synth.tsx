type Props = {
  classNames?: string;
};

const Synth = ({ classNames }: Props) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      className={classNames}
    >
      <path
        className="animate-soundwave origin-center"
        d="m19,8v8c0,.553-.447,1-1,1s-1-.447-1-1v-8c0-.553.447-1,1-1s1,.447,1,1ZM14,0c-.553,0-1,.447-1,1v22c0,.553.447,1,1,1s1-.447,1-1V1c0-.553-.447-1-1-1Zm8,4c-.553,0-1,.447-1,1v14c0,.553.447,1,1,1s1-.447,1-1V5c0-.553-.447-1-1-1Zm-12,0c-.553,0-1,.447-1,1v14c0,.553.447,1,1,1s1-.447,1-1V5c0-.553-.447-1-1-1Zm-4,3c-.553,0-1,.447-1,1v8c0,.553.447,1,1,1s1-.447,1-1v-8c0-.553-.447-1-1-1Zm-4,2c-.553,0-1,.447-1,1v4c0,.553.447,1,1,1s1-.447,1-1v-4c0-.553-.447-1-1-1Z"
      />
    </svg>
  );
};

export default Synth;
