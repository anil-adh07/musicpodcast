type Props = {
  classNames?: string;
};

const PlayerNav = ({ classNames }: Props) => {
  return (
    <svg viewBox="0 0 24 24" focusable="false" className={classNames}>
      <g>
        <path d="M5,18l10-6L5,6V18L5,18z M19,6h-2v12h2V6z" />
      </g>
    </svg>
  );
};

export default PlayerNav;
