type Props = {
  classNames?: string;
};

const Playlist = ({ classNames }: Props) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      className={classNames}
    >
      <polygon points="2 3 2 11 8 7 2 3" />
      <path d="M3 14.5H21a1 1 0 0 0 0-2H3a1 1 0 0 0 0 2zM10 7a1 1 0 0 0 1 1H21a1 1 0 0 0 0-2H11A1 1 0 0 0 10 7zM3 21H21a1 1 0 0 0 0-2H3a1 1 0 0 0 0 2z" />
    </svg>
  );
};

export default Playlist;
