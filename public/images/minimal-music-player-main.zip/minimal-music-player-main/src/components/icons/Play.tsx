type Props = {
  classNames?: string;
};

const Play = ({ classNames }: Props) => {
  return (
    <svg viewBox="0 0 24 24" className={classNames}>
      <g>
        <path d="M6,4l12,8L6,20V4z" />
      </g>
    </svg>
  );
};

export default Play;
