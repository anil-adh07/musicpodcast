const Skeleton = () => {
  return (
    <div className="cursor-progress w-full h-80 rounded-xl block bg-neutral-800 animate-pulse" />
  );
};

export default Skeleton;
