import { ReactElement } from "react";

type ButtonProps = {
  classNames?: string;
  children: ReactElement;
  disabled: boolean;
  isPrimary: boolean;
  onClick: () => void;
};
const PlayerButton = ({
  classNames,
  children,
  disabled,
  isPrimary,
  onClick,
}: ButtonProps) => {
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      type="button"
      className={`
        ${
          isPrimary
            ? "bg-neutral-100 hover:bg-neutral-300"
            : "hover:bg-neutral-700/50"
        }
        ${classNames ? classNames : "w-10 h-10"}
        rounded-full
        disabled:cursor-not-allowed
        shrink-0
        inline-flex
        items-center
        justify-center
      `}
    >
      {children}
    </button>
  );
};

export default PlayerButton;
