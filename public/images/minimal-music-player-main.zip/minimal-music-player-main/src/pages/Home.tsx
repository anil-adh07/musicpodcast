import { useEffect, useState } from "react";
import InfiniteScroll from "react-infinite-scroll-component";
import ArtistCard from "../components/Card";
import Skeleton from "../components/Skeleton";
import Search from "../components/Search";

const Home = () => {
  const baseUrl = import.meta.env.VITE_JAMENDO_API_URI;
  const clientId = import.meta.env.VITE_JAMENDO_CLIENT_ID;

  const [artists, setArtists] = useState<
    Array<{
      id: string;
      name: string;
      website: string;
      joindate: string;
      image: string;
      shorturl: string;
      shareurl: string;
    }>
  >([]);
  const [loadMoreUri, setLoadMoreUri] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(false);
  const skeletons = Array(5).fill(<Skeleton />);

  const fetchArtists = async (searchTerm?: string) => {
    setLoading(true);
    const response = await fetch(
      searchTerm?.length
        ? `${baseUrl}/artists?client_id=${clientId}&format=jsonpretty&namesearch=${searchTerm}`
        : loadMoreUri
        ? loadMoreUri
        : `${baseUrl}/artists?client_id=${clientId}&format=jsonpretty&hasimage=true&order=popularity_total_desc`
    )
      .then((res) => res.json())
      .catch((e) => console.log(e));
    if (searchTerm?.length) {
      setArtists(response.results);
    } else {
      !response?.results?.length
        ? setArtists([])
        : artists?.length
        ? setArtists([...artists, ...response.results])
        : setArtists(response.results);
    }
    if (response?.headers?.next && response?.headers?.next.length) {
      setLoadMoreUri(response.headers.next);
      setHasMore(true);
      setLoading(false);
    } else {
      setLoadMoreUri(null);
      setHasMore(false);
      setLoading(false);
    }
  };

  const searchArtists = async (searchTerm: string) => {
    await fetchArtists(searchTerm);
  };

  const loadMoreArtists = () => {
    if (!loadMoreUri) {
      return setHasMore(false);
    }
    return fetchArtists();
  };

  useEffect(() => {
    if (!artists?.length) {
      fetchArtists();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <h1 className="text-neutral-100 text-2xl font-bold">Top artists</h1>
      <Search updateSearchTerm={searchArtists} />
      <InfiniteScroll
        dataLength={artists?.length}
        next={loadMoreArtists}
        hasMore={hasMore}
        loader={skeletons.map((card, index) => (
          <Skeleton key={`${card} + ${index}`} />
        ))}
        endMessage={<span />}
        className="w-full mx-auto grid lg:grid-cols-4 md:grid-cols-2 grid-cols-1 gap-5 mt-10"
      >
        {artists?.map(
          (artist: {
            id: string;
            name: string;
            website: string;
            joindate: string;
            image: string;
            shorturl: string;
            shareurl: string;
          }) => (
            <ArtistCard
              key={artist.id}
              name={artist.name}
              image={artist.image}
              query={artist.id}
            />
          )
        )}
        {loading &&
          !artists.length &&
          skeletons.map((card, index) => (
            <Skeleton key={`${card} + ${index}`} />
          ))}
        {!artists?.length && !hasMore && !loadMoreUri && !loading && (
          <div
            role="alert"
            className="lg:col-span-4 md:col-span-2 rounded-md bg-red-200 p-4 h-12 text-center"
          >
            <p className="text-sm text-red-700">No artists found!</p>
          </div>
        )}
      </InfiniteScroll>
    </>
  );
};

export default Home;
