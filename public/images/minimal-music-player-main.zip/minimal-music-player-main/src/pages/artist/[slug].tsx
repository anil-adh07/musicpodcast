import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import Markdown from "markdown-to-jsx";
import moment from "moment";
import { shuffle } from "../../utils/data";
import ArrowLeft from "../../components/icons/ArrowLeft";
import Track from "../../components/Track";
import Shuffle from "../../components/icons/Shuffle";
import PlayerButton from "../../components/PlayerButton";

type TrackPropType = {
  album_id: string;
  album_image: string;
  album_name: string;
  audio: string;
  audiodownload: string;
  audiodownload_allowed: boolean;
  duration: string;
  id: string;
  image: string;
  license_ccurl: string;
  name: string;
  releasedate: string;
};

type Props = {
  openTrackPlayer: (tracks: TrackPropType[], index: number) => void;
};

const ArtistPage = ({ openTrackPlayer }: Props) => {
  const params = useParams();
  const baseUrl = import.meta.env.VITE_JAMENDO_API_URI;
  const clientId = import.meta.env.VITE_JAMENDO_CLIENT_ID;

  const [artist, setArtist] = useState<{
    id: string;
    image: string;
    joindate: string;
    name: string;
    tracks: Array<TrackPropType>;
    website: string;
  } | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const skeletons = Array(5).fill(<></>);

  const searchArtist = async () => {
    setLoading(true);
    const response = await fetch(
      `${baseUrl}/artists/tracks?client_id=${clientId}&format=jsonpretty&imagesize=600&order=track_name_desc&id=${params?.slug}`
    )
      .then((res) => res.json())
      .catch((e) => console.log(e));
    if (response?.results?.length) {
      setArtist(response?.results[0]);
      setLoading(false);
    }
  };

  const playTrack = (index: number) => {
    if (artist && artist.tracks.length) {
      return openTrackPlayer(artist.tracks, index);
    }
  };

  const shuffleTracks = () => {
    if (artist && artist.tracks.length) {
      const shuffled = shuffle(artist.tracks);
      if (shuffled && shuffled.length) {
        return openTrackPlayer(shuffled, 0);
      }
    }
  };

  useEffect(() => {
    searchArtist();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <Link to="/" className="group">
        <ArrowLeft classNames="group-hover:-translate-x-2 transition-all duration-200 w-6 fill-neutral-100" />
      </Link>
      <div className="relative md:pt-12 pt-8 w-full flex md:flex-nowrap flex-wrap items-center gap-4">
        <div className="h-auto">
          <div className="lg:w-52 md:w-36 w-24 lg:h-52 md:h-36 h-24  block overflow-hidden rounded-full">
            {loading ? (
              <div className="w-full h-full bg-neutral-800 animate-pulse" />
            ) : (
              <img
                src={
                  artist?.image?.length
                    ? artist?.image
                    : `https://source.unsplash.com/600x600?${artist?.name}+music`
                }
                alt={artist?.name}
                className="w-full h-auto"
              />
            )}
          </div>
        </div>
        <div className="w-full flex flex-col space-y-2">
          {loading ? (
            <>
              <div className="md:w-1/2 h-16 w-full rounded bg-neutral-800 animate-pulse" />
              <div className="md:w-64 h-8 w-full rounded bg-neutral-800 animate-pulse" />
            </>
          ) : (
            <>
              {artist && artist.name && (
                <Markdown
                  options={{ wrapper: "h1", forceWrapper: true }}
                  className="text-neutral-100 md:text-6xl text-4xl font-bold capitalize break-words"
                >
                  {artist.name}
                </Markdown>
              )}
              <p className="text-neutral-200 text-lg">
                Joined{" "}
                <strong>
                  {moment(artist?.joindate).format("DD MMMM, YYYY")}
                </strong>
              </p>
            </>
          )}
        </div>
      </div>
      <div className="py-16 w-full md:px-5">
        <div className="w-full bg-neutral-900 sticky top-0 z-10 pt-4">
          <h3 className="text-neutral-100 md:text-3xl text-2xl font-semibold">
            Tracks
          </h3>
          <div className="flex md:w-1/2 w-full items-center gap-3 py-2">
            <PlayerButton
              classNames="md:w-16 md:h-16 w-12 h-12"
              children={<Shuffle classNames="md:w-7 w-5 fill-neutral-200" />}
              disabled={false}
              isPrimary={false}
              onClick={shuffleTracks}
            />
          </div>
        </div>
        {loading ? (
          <div className="mt-8 flex flex-col gap-2">
            {skeletons.map((card, index) => (
              <div
                key={`${card} + ${index}`}
                className="w-full h-16 rounded bg-neutral-800 animate-pulse"
              />
            ))}
          </div>
        ) : (
          artist?.tracks?.length && (
            <ul className="mt-8 md:text-lg text-base">
              {artist?.tracks?.map((track, index: number) => (
                <li
                  key={index}
                  className="group cursor-pointer w-full flex items-center gap-4 text-neutral-100 p-2.5 rounded hover:bg-neutral-800"
                  title={track.name}
                  onClick={() => playTrack(index)}
                >
                  <Track track={track} />
                </li>
              ))}
            </ul>
          )
        )}
      </div>
    </>
  );
};

export default ArtistPage;
