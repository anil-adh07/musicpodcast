import ColorThief from "color-thief-ts";

export const convertDuration = (duration: string) => {
  // Calculate the hours, minutes, and seconds
  const hours = Math.floor(parseInt(duration) / 3600)
  const minutes = Math.floor((parseInt(duration) % 3600) / 60)
  const seconds = parseInt(duration) % 60

  const time = hours > 0 ?
    `${hours < 10 ? `0${hours}` : hours}:${minutes < 10 ? `0${minutes}` : minutes}:${seconds < 10 ? `0${seconds}` : seconds}` :
    minutes > 0 ? `${minutes < 10 ? `0${minutes}` : minutes}:${seconds < 10 ? `0${seconds}` : seconds}` :
      `00:${seconds < 10 ? `0${seconds}` : seconds}`

  return time
}

export const generateRandomBgColor = () => {
  const red = Math.floor(Math.random() * (255 - 0) + 0)
  const green = Math.floor(Math.random() * (255 - 0) + 0)
  const blue = Math.floor(Math.random() * (255 - 0) + 0)

  const bgColor = `rgba(${red}, ${green}, ${blue}, 0.2)`

  return bgColor
}

type TrackProps = {
  album_id: string,
  album_image: string,
  album_name: string,
  audio: string,
  audiodownload: string,
  audiodownload_allowed: boolean,
  duration: string,
  id: string,
  image: string,
  license_ccurl: string,
  name: string,
  releasedate: string
}

export const shuffle = (array: TrackProps[]) => {
  const result = array.map(value => ({ value, sort: Math.random() }))
    .sort((a, b) => a.sort - b.sort)
    .map(({ value }) => value)
  return result
}

export const extractDominantColor = async (imageUrl: string) => {
  const colorThief = new ColorThief();
  const dominantColor = await colorThief.getColorAsync(imageUrl);
  return dominantColor;
}