declare module 'color-thief-ts' {
  export type RGBColor = [number, number, number];
  export default class ColorThief {
    getColorAsync: (img: string | null, quality: number = 10) => RGBColor;
    getPaletteAsync: (img: string | null, colorCount: number = 10, quality: number = 10) => RGBColor[];
  }
}